
/**
 * @author: ParkHyeokJoon
 * @since : 2018.08.30
 * @version : 2018.08.30
 */

export interface ISuggestState {
    text:string;
    start: number;
    end: number;
    positionX: number;
    positionY: number;
}